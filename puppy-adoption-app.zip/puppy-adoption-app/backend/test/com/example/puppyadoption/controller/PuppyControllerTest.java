package com.example.puppyadoption.controller;

import com.example.puppyadoption.model.Puppy;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import javax.annotation.Resource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class PuppyControllerTest {

    @Resource
    private MockMvc mockMvc;

    @Test
    public void testGetPuppies() throws Exception {
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/puppies")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        // Assert the response and verify the content
        String responseBody = result.getResponse().getContentAsString();
        Puppy[] puppies = new ObjectMapper().readValue(responseBody, Puppy[].class);
        assertEquals(2, puppies.length); // Adjust the expected count based on your test data
    }
}
