import java.util.List;

public class Puppy {
    private String id;
    private String name;
    private int age;
    private String gender;
    private boolean isVaccinated;
    private boolean isNeutered;
    private String size;
    private String breed;
    private List<String> traits;
    private String photoUrl;
    private String description;
    private String personalityTraits;
    private String vaccinationRecords;
    private String adoptionRequirements;

    // Constructors, getters, and setters
}
