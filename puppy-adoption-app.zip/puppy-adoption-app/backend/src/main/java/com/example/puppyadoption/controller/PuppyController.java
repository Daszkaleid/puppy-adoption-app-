package com.example.puppyadoption.controller;

import com.example.puppyadoption.model.Puppy;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/puppies")
public class PuppyController {
    private List<Puppy> puppies = new ArrayList<>();

    @GetMapping
    public List<Puppy> getPuppies() {
        return puppies;
    }

    @PostMapping
    public void addPuppy(@RequestBody Puppy puppy) {
        puppies.add(puppy);
    }

    @GetMapping("/{id}")
    public Puppy getPuppyById(@PathVariable String id) {
        for (Puppy puppy : puppies) {
            if (puppy.getId().equals(id)) {
                return puppy;
            }
        }
        return null;
    }

    @PutMapping("/{id}")
    public void updatePuppy(@PathVariable String id, @RequestBody Puppy updatedPuppy) {
        for (Puppy puppy : puppies) {
            if (puppy.getId().equals(id)) {
                puppy.setName(updatedPuppy.getName());
                puppy.setAge(updatedPuppy.getAge());
                puppy.setGender(updatedPuppy.getGender());
                puppy.setIsVaccinated(updatedPuppy.isIsVaccinated());
                puppy.setIsNeutered(updatedPuppy.isIsNeutered());
                puppy.setSize(updatedPuppy.getSize());
                puppy.setBreed(updatedPuppy.getBreed());
                puppy.setTraits(updatedPuppy.getTraits());
                puppy.setPhotoUrl(updatedPuppy.getPhotoUrl());
                return;
            }
        }
    }

    @DeleteMapping("/{id}")
    public void deletePuppy(@PathVariable String id) {
        puppies.removeIf(puppy -> puppy.getId().equals(id));
    }
}
