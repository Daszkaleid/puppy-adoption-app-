import React, { useEffect, useState } from 'react';
import PuppyList from './PuppyList';
import PuppyFilter from './PuppyFilter';
import PuppyProfile from './PuppyProfile';

const App = () => {
  const [puppies, setPuppies] = useState([]);
  const [filteredPuppies, setFilteredPuppies] = useState([]);

  useEffect(() => {
    // Fetch the puppy data from the backend API
    fetch('your-api-url/puppies')
      .then((response) => response.json())
      .then((data) => {
        setPuppies(data);
        setFilteredPuppies(data);
      })
      .catch((error) => console.log(error));
  }, []);

  const handleFilter = ({ breed, age, searchKeyword }) => {
    // Filter the puppies based on the provided criteria
    let filtered = puppies;
    if (breed) {
      filtered = filtered.filter((puppy) => puppy.breed === breed);
    }
    if (age) {
      filtered = filtered.filter((puppy) => puppy.age === age);
    }
    if (searchKeyword) {
      filtered = filtered.filter((puppy) =>
        puppy.name.toLowerCase().includes(searchKeyword.toLowerCase())
      );
    }
    setFilteredPuppies(filtered);
  };

  return (
    <div>
      <PuppyFilter handleFilter={handleFilter} />
      <PuppyList puppies={filteredPuppies} />
      {/* Render individual puppy profiles and adoption form */}
    </div>
  );
};

export default App;
