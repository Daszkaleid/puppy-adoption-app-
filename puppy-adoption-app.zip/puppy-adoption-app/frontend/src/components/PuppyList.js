import React from 'react';

const PuppyList = ({ puppies }) => {
  return (
    <div>
      <h1>List of Available Puppies</h1>
      {puppies.map((puppy) => (
        <div key={puppy.name}>
          <h2>{puppy.name}</h2>
          <p>Breed: {puppy.breed}</p>
          <p>Age: {puppy.age}</p>
          <p>Description: {puppy.description}</p>
          <img src={puppy.photoUrl} alt={puppy.name} />
        </div>
      ))}
    </div>
  );
};

export default PuppyList;
