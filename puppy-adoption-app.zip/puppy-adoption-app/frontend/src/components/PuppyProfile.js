import React from 'react';

const PuppyProfile = ({ puppy }) => {
  return (
    <div>
      <h1>{puppy.name}</h1>
      <p>Breed: {puppy.breed}</p>
      <p>Age: {puppy.age}</p>
      <p>Description: {puppy.description}</p>
      <img src={puppy.photoUrl} alt={puppy.name} />
      {/* Display more details and adoption form */}
    </div>
  );
};

export default PuppyProfile;
