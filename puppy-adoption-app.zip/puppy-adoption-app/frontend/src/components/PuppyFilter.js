import React, { useState } from 'react';

const PuppyFilter = ({ handleFilter }) => {
  const [breed, setBreed] = useState('');
  const [age, setAge] = useState('');
  const [searchKeyword, setSearchKeyword] = useState('');

  const handleSearch = () => {
    // Call handleFilter function to pass the filter values
    handleFilter({ breed, age, searchKeyword });
  };

  return (
    <div>
      <h2>Filter and Search Puppies</h2>
      <input
        type="text"
        placeholder="Breed"
        value={breed}
        onChange={(e) => setBreed(e.target.value)}
      />
      <input
        type="text"
        placeholder="Age"
        value={age}
        onChange={(e) => setAge(e.target.value)}
      />
      <input
        type="text"
        placeholder="Search"
        value={searchKeyword}
        onChange={(e) => setSearchKeyword(e.target.value)}
      />
      <button onClick={handleSearch}>Search</button>
    </div>
  );
};

export default PuppyFilter;
